//Autori del progetto
//==================================================================
//ANGELLA LORENZO NR° MATRICOLA 737854
//FRATTINI GAIA NR° MATRICOLA 736610
//FRANTINI LUCA NR° MATRICOLA 738864
//GALBIATI GIUSEPPE MATTIA NR° MATRICOLA 737533
//==================================================================
// importazioni librerie :
import java.io.FileReader;    //libreria per lettura file
import java.lang.Math;        //libreria per utilizzo della matematica
import java.util.ArrayList;   //libreria per utilizzo degli attributi agli arraylisti
import java.util.LinkedList;  //libreria per liste "puntate"
import java.io.BufferedReader;//libreria per un buffer di lettura
import java.io.IOException;   //libreria per le eccezioni

//Machine Spirit
public class EmotionMaps
{
//core
  public static void main(String[] args)
  {
    ArrayList<Entry> data = new ArrayList<Entry>();	   //arraylist utilizzato come database
    LinkedList<User> udata=new LinkedList<User>();    //arraylist utilizzato come registro utenze
    ArrayList<int[][][]> index = new ArrayList<int[][][]>(); 	//data for getting the indices of entries sorted by date
    LinkedList<String> chant = new LinkedList<String>();      //creazione di una lista
    ReaderAndPosition(args[0],chant);
    while(chant.size()>0)
    {
	    String ch = chant.getFirst(); chant.removeFirst();    //prende il primo elemento e lo rimuove dalla lista posizionandolo nella stringa
	    System.out.println(ch);                               //stampa la stringa
	    if(ch.contentEquals("import"))                        //controllo se uguale alla parola "import"
	    {
		    ch=chant.getFirst();chant.removeFirst();            //prende il primo elemento e lo rimuove dalla lista posizionandolo nella stringa
		    AcquireData(ch,data,index,udata);                   //salva la stringa la data, l'indice e l'utente
	    }
	    else if(ch.equals("create_map"))                      //controllo se uguale alla parola "create_map"
	    {
		    ch=chant.getFirst();chant.removeFirst();            //prende il primo elemento e lo rimuove dalla lista posizionandolo nella stringa
		    LinkedList<Entry> pass =new LinkedList<Entry>();
		    FillByInterval(ch,pass,index,data);
		    creaMappa(pass);
	    }
	    else
		    System.out.println("error");
     }
//System.out.println(data.get(0).x);
    }
//rite of understanding
private static void ReaderAndPosition(String c,LinkedList<String> destination)
{
	try{
	  BufferedReader reader = new BufferedReader(new FileReader(c));// nuova lettura file dove il nome è scritto dentro la stringa c
	  String Data = reader.readLine();                              //legge la riga
	  while(Data!=null){
		    String arg=Data.split("\\(")[1];
		    destination.add(Data.split("\\(")[0]);                    //aggiunge alla lista
		    destination.add(arg.substring(0,arg.length()-1 ));        //aggiunge alla lista
		    Data=reader.readLine();                                   //lettura riga
	    }
	  reader.close();//chiusura lettura filr
	}
	catch(IOException e){
	  System.out.println("Error encountered while reading file. Have you tried to lighting some incense?");  //errore nella lettura file
	}
}
//rite of acquisition

private static void AcquireData(String s,ArrayList<Entry> d,ArrayList<int[][][]> q,LinkedList<User> u)
{
    try{
    BufferedReader reader = new BufferedReader(new FileReader(s));//lettura file nominato nella variabili string S
    String Data = reader.readLine();//lettura riga file
    while(Data!=null){
    //System.out.println(Data);
      Entry e=GetIntoBox(Elaborate(Data),d.size(),q,u);// aggiunta all'ArrayList della elaborazione della data, dimensione e utenza
      if (e.Type==0)
      d.add(e); //aggiunta dell oggetto e a d
      else
      RemoveAccount(e.code,u,d); //rimozione account e dati annessi
      //System.out.println("data acquired");
      Data=reader.readLine();//lettura riga
      }
    reader.close();
    }
    catch(IOException e)
    {
       System.out.println("Error encountered while reading file. Have you tried lighting some incense?");
  }
}

private static void RemoveAccount(String ucode,LinkedList<User> udata, ArrayList<Entry> d) //funzione rimozione user
{
	User u=getUsr(udata,ucode);
	if(u!=null)
	{
	  for(int i : u.indices)
	  {
		  d.set(i,null); //settal'indice a null
	  }
	  udata.remove(u);//rimuove l'utente u
	 }
	 d.add(null); //this is the entry that caused the account deletion. it's inserted because it still contributes to the total events count
 }
 //sub rite of acquisition
private static Entry Elaborate(String s)//registrazione date da file a struttura dati (variabili)
{
  int d,m,ye,typ;
  double x,y;
  char em;
  String user=s.split(" ")[3];
  typ=(s.split(" ")[0].equals("IN")? 0 : 1);
  String date = s.split(" ")[2];
  //day
  d=Character.getNumericValue(date.charAt(0));//casting in numero del giorno
  d=d*10+Character.getNumericValue(date.charAt(1));
  //System.out.println(d);
  //month
  m=Character.getNumericValue(date.charAt(2));//casting in numero del mese
  m=m*10+Character.getNumericValue(date.charAt(3));
  //System.out.println(m);
  //year
  ye=Character.getNumericValue(date.charAt(4));//casting in numero del anno
  ye=ye*10+Character.getNumericValue(date.charAt(5));
  ye=ye*10+Character.getNumericValue(date.charAt(6));
  ye=ye*10+Character.getNumericValue(date.charAt(7));
  //System.out.println(ye);
  //coordinates
  x= Double.valueOf(s.split(" ")[4].split(",")[0]);
  y= Double.valueOf(s.split(" ")[4].split(",")[1]);
  //System.out.println(x);
  //System.out.println(y);
  em=s.split(" ")[5].charAt(0);
  return(new Entry(d,m,ye,x,y,em,user,typ));//dati che ritornano alla chiamata
}

public static Entry GetIntoBox(Entry e, int p, ArrayList<int[][][]> a, LinkedList<User> u)  //metodo per la gestione differenza di date
{
	if(a.size()<e.Y-2018)
		a.add(new int [12][31][2]);
	if(a.get(e.Y-2019)[e.m][e.d][0]==0)
	  a.get(e.Y-2019)[e.m][e.d][0]=p;
	else
		a.get(e.Y-2019)[e.m][e.d][1]++;
	if(a.get(e.Y-2019)[e.m][e.d][1]==0)
		a.get(e.Y-2019)[e.m][e.d][1]=a.get(e.Y-2019)[e.m][e.d][0];
	User user=getUsr(u, e.code);
	if(user==null)
	  u.add(new User(e.code,p));
	else
	  user.indices.add(p);
	return e;
}

private static User getUsr(LinkedList<User> u,String cd)//per la ricerca utente corretto
{
	if (u.size()!=0)
  {
	  LinkedList<User> usrs=u;
	  User user = usrs.getFirst();
	  usrs.removeFirst();
	  do {
	    if(!user.code.equals(cd))
	    return user;
	  }while(usrs.size()>0);
  }
	return null;
}

private static void FillByInterval(String s,LinkedList<Entry> l,ArrayList<int[][][]> a,ArrayList<Entry> data)
{
	int lo=0,hi=0,d=0,m=0,y=0;
	for(int i=0;i<2;i++)
	{
		String interval=s.split("-")[i];
	  d=Character.getNumericValue(interval.charAt(0));
	  d=d*10+Character.getNumericValue(interval.charAt(1));
	  m=Character.getNumericValue(interval.charAt(2));
	  m=m*10+Character.getNumericValue(interval.charAt(3));
	  y=Character.getNumericValue(interval.charAt(4));
	  y=y*10+Character.getNumericValue(interval.charAt(5));
	  y=y*10+Character.getNumericValue(interval.charAt(6));
	  y=y*10+Character.getNumericValue(interval.charAt(7));
	  if(i==0)
		  lo = a.get(y-2019)[m][d][0];
	  else
		  hi = a.get(y-2019)[m][d][1];
	  }
	  for(int i=lo;i<=hi;i++)
	  {
		  Entry ent = data.get(i);
		  if(ent!=null)
		    l.add(ent);
	  }
}
//rite of localization
public static void creaMappa(LinkedList<Entry> d){
	double[] POI1={0,0,0,0,0},POI2={0,0,0,0,0},POI3={0,0,0,0,0};
  int p1=0,p2=0,p3=0;
  while(d.size()>0)
  {
    Entry e = d.getFirst();d.removeFirst();
    int i=assignPOI(e);
    switch(i)
    {
      case 1:
      switch(e.s)
      {
      case 'A':
      POI1[0]+=1;
      p1++;
      break;
      case 'F':
      POI1[1]++;
      p1++;
      break;
      case 'S':
      POI1[2]++;
      p1++;
      break;
      case 'T':
      POI1[3]++;
      p1++;
      break;
      case 'N':
      POI1[4]++;
      p1++;
      break;
    }
    break;
    case 2:
    switch(e.s)
    {
      case 'A':
      POI2[0]++;
      p2++;
      break;
      case 'F':
      POI2[1]++;
      p2++;
      break;
      case 'S':
      POI2[2]++;
      p2++;
      break;
      case 'T':
      POI2[3]++;
      p2++;
      break;
      case 'N':
      POI2[4]++;
      p2++;
      break;
    }
    break;
    case 3:
    switch(e.s)
    {
      case 'A':
      POI3[0]++;
      p3++;
      break;
      case 'F':
      POI3[1]++;
      p3++;
      break;
      case 'S':
      POI3[2]++;
      p3++;
      break;
      case 'T':
      POI3[3]++;
      p3++;
      break;
      case 'N':
      POI3[4]++;
      p3++;
      break;
    }
    break;
  }
 }
    //transform value into percentage
    //stampa delle percentuali
    printPercentage(POI1,p1,1);
    printPercentage(POI2,p2,2);
    printPercentage(POI3,p3,3);
}

//sub rite of localization
public static int assignPOI(Entry e){
//declaring coordinates holders
double x1,x2,x3,y1,y2,y3;
//assigning numerical coordinates
x1=45.464;
y1=9.190;
x2=45.473;
y2=9.173;
x3=45.458;
y3=9.181;
//stuff it needs to work
double d1,d2,d3;
//calculating distances from POIs
d1=Math.pow((e.x-x1),2);
d1=d1+Math.pow(e.y-y1,2);
d1=Math.pow(d1,0.5);

d2= Math.pow((e.x-x2),2);
d2=d2+Math.pow(e.y-y2,2);
d2=Math.pow(d2,0.5);

d3=Math.pow((e.x-x3),2);
d3=d3+Math.pow(e.y-y3,2);
d3=Math.pow(d3,0.5);

//choosing nearest POI
if(d1<=d2 && d1<=d3)
return 1;
else if(d2<d1 && d2<=d3)
return 2;
else if(d3<d1 && d3<d2)
return 3;
return 0;
}

private static void printPercentage(double[] POI,int tot,int q)//metodo per le stampe in percentuale
{
	if(tot==0)
		tot=1;
 for(int i=0;i<5;i++)
 {
	 POI[i]=POI[i]/tot*100;
 }
System.out.println("POI"+q+" A:"+POI[0]+"% F:"+POI[1]+"% S:"+POI[2]+"% T:"+POI[3]+"% N:"+POI[4]);

}
//praised be the Omnissiah
}
