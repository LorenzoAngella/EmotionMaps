//Autori del progetto
//==================================================================
//ANGELLA LORENZO NR° MATRICOLA 737854
//FRATTINI GAIA NR° MATRICOLA 736610
//FRANTINI LUCA NR° MATRICOLA 738864
//GALBIATI GIUSEPPE MATTIA NR° MATRICOLA 737533
//==================================================================
//data holder entity
class Entry 
{
public int d,m,Y;
public double x,y;
public char s;
public String code;
public int Type;

public Entry(int q,int w,int r,double x, double y, char s,String code,int typ) //rite of building
{
d=q;
m=w;
Y=r;
this.x=x;
this.y=y;
this.s=s;
this.code=code;
Type=typ;
}

}






