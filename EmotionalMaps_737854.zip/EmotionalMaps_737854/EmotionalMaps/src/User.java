//Autori del progetto
//==================================================================
//ANGELLA LORENZO NR° MATRICOLA 737854
//FRATTINI GAIA NR° MATRICOLA 736610
//FRANTINI LUCA NR° MATRICOLA 738864
//GALBIATI GIUSEPPE MATTIA NR° MATRICOLA 737533
//==================================================================
import java.util.LinkedList;

class User
{
	public String code;
	public LinkedList<Integer> indices;
	
	public User(String code,int ind)
	{
		this.code=code;
		this.indices=new LinkedList<Integer>();
		indices.add(ind);
	}
}
